# Kawaii Music 2.0

Rebuilt from the supplied APK shell/UI and upgraded with native Android media access.

### Main upgrades
- Scans the Android MediaStore audio library automatically instead of requiring one-by-one imports.
- Uses `READ_MEDIA_AUDIO` on Android 13+ and `READ_EXTERNAL_STORAGE` on older Android versions.
- Streams `content://` MediaStore tracks through a `WebViewAssetLoader` path handler and handles HTTP byte ranges for media seeking.
- Shows album groups inside the Playlist page.
- Reads embedded album artwork and exposes it to the WebView.
- Lets each track store a custom title, artist, album name and custom cover.
- Shows the same title/artist/album artwork in the native MediaStyle notification.
- Starts a `mediaPlayback` foreground service while a track is loaded so notification controls can keep working when the UI is backgrounded.

### GitHub build
The repository contains `.github/workflows/build.yml`. It builds a release APK with Android Gradle Plugin 8.13.0 / Gradle 8.13 / JDK 17 and uploads the APK as a workflow artifact.

### Important platform behavior
The app can scan audio exposed by Android's MediaStore. Files kept in another app's private sandbox are not visible to MediaStore and cannot be scanned by a normal app without that app exposing them.
