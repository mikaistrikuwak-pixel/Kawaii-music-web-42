# No custom shrinker rules are required. Native bridge methods are kept by @JavascriptInterface.
