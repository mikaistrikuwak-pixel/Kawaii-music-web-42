package com.kawaii.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.IBinder;
import android.text.TextUtils;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import androidx.media.session.MediaSessionCompat;
import android.support.v4.media.MediaMetadataCompat;

import android.support.v4.media.session.PlaybackStateCompat;


public class MediaService extends Service {
    static final String ACTION_UPDATE = "com.kawaii.music.UPDATE";
    static final String ACTION_PLAY = "com.kawaii.music.PLAY";
    static final String ACTION_PAUSE = "com.kawaii.music.PAUSE";
    static final String ACTION_PREV = "com.kawaii.music.PREV";
    static final String ACTION_NEXT = "com.kawaii.music.NEXT";
    static final String ACTION_BACK10 = "com.kawaii.music.BACK10";
    static final String ACTION_FWD10 = "com.kawaii.music.FWD10";
    static final String ACTION_STOP = "com.kawaii.music.STOP";
    private static final int NOTIF_ID = 7007;
    private static final String CHANNEL_ID = "kawaii_music_playback";

    private MediaSessionCompat mediaSession;
    private String title = "Kawaii Music";
    private String artist = "";
    private String album = "";
    private String artDataUrl = "";
    private boolean playing;
    private long positionMs;
    private long durationMs;
    private boolean foregroundStarted;
    private static volatile boolean running;

    static boolean isRunning() { return running; }

    static void update(Context context, String title, String artist, String album, String art,
                       boolean playing, long positionMs, long durationMs) {
        Intent i = new Intent(context, MediaService.class);
        i.setAction(ACTION_UPDATE);
        i.putExtra("title", title);
        i.putExtra("artist", artist);
        i.putExtra("album", album);
        i.putExtra("art", art);
        i.putExtra("playing", playing);
        i.putExtra("pos", positionMs);
        i.putExtra("dur", durationMs);
        try {
            if (playing || isRunning()) {
                if (Build.VERSION.SDK_INT >= 26 && !isRunning()) context.startForegroundService(i);
                else context.startService(i);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        createChannel();
        mediaSession = new MediaSessionCompat(this, "KawaiiMusic");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { MainActivity.dispatchToWeb("play"); }
            @Override public void onPause() { MainActivity.dispatchToWeb("pause"); }
            @Override public void onSkipToPrevious() { MainActivity.dispatchToWeb("prev"); }
            @Override public void onSkipToNext() { MainActivity.dispatchToWeb("next"); }
            @Override public void onSeekTo(long pos) { MainActivity.dispatchToWeb("seek:" + pos); }
            @Override public void onStop() { MainActivity.dispatchToWeb("stop"); stopSelf(); }
        });
        mediaSession.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_UPDATE.equals(action)) {
            title = safe(intent.getStringExtra("title"));
            artist = safe(intent.getStringExtra("artist"));
            album = safe(intent.getStringExtra("album"));
            artDataUrl = safe(intent.getStringExtra("art"));
            playing = intent.getBooleanExtra("playing", false);
            positionMs = intent.getLongExtra("pos", 0L);
            durationMs = intent.getLongExtra("dur", 0L);
            startOrUpdateForeground();
        } else if (ACTION_PLAY.equals(action)) MainActivity.dispatchToWeb("play");
        else if (ACTION_PAUSE.equals(action)) MainActivity.dispatchToWeb("pause");
        else if (ACTION_PREV.equals(action)) MainActivity.dispatchToWeb("prev");
        else if (ACTION_NEXT.equals(action)) MainActivity.dispatchToWeb("next");
        else if (ACTION_BACK10.equals(action)) MainActivity.dispatchToWeb("back10");
        else if (ACTION_FWD10.equals(action)) MainActivity.dispatchToWeb("fwd10");
        else if (ACTION_STOP.equals(action)) { MainActivity.dispatchToWeb("stop"); clearAndStop(); }
        return START_STICKY;
    }

    private void startOrUpdateForeground() {
        Bitmap cover = decodeArt(artDataUrl);
        updateMediaSessionMetadata(cover);
        Notification n = buildNotification(cover);
        if (!foregroundStarted) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ServiceCompat.startForeground(this, NOTIF_ID, n,
                            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
                } else {
                    startForeground(NOTIF_ID, n);
                }
                foregroundStarted = true;
            } catch (SecurityException ignored) {
                // Android 13+ notification permission may be denied; playback can still continue.
                try { startForeground(NOTIF_ID, n); foregroundStarted = true; } catch (Throwable ignored2) {}
            }
        } else {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, n);
        }
        updatePlaybackState();
    }

    private void updateMediaSessionMetadata(Bitmap cover) {
        if (mediaSession == null) return;
        MediaMetadataCompat.Builder m = new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album);
        if (cover != null) m.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, cover);
        mediaSession.setMetadata(m.build());
    }

    private Notification buildNotification(Bitmap cover) {
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.kawaii.music.R.mipmap.ic_launcher)
                .setContentTitle(TextUtils.isEmpty(title) ? "Kawaii Music" : title)
                .setContentText(TextUtils.isEmpty(artist) ? "Unknown" : artist)
                .setSubText(album)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setShowWhen(false)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(PendingIntent.getActivity(this, 0,
                        new Intent(this, MainActivity.class),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        if (cover != null) b.setLargeIcon(cover);

        MediaStyle style = new MediaStyle().setMediaSession(mediaSession.getSessionToken())
                .setShowActionsInCompactView(1, 2, 3);
        b.setStyle(style);

        b.addAction(new NotificationCompat.Action.Builder(
                android.R.drawable.ic_media_rew,
                "−10",
                pendingAction(ACTION_BACK10)).build());
        b.addAction(new NotificationCompat.Action.Builder(
                android.R.drawable.ic_media_previous,
                "Sebelumnya",
                pendingAction(ACTION_PREV)).build());
        b.addAction(new NotificationCompat.Action.Builder(
                playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                playing ? "Jeda" : "Putar",
                pendingAction(playing ? ACTION_PAUSE : ACTION_PLAY)).build());
        b.addAction(new NotificationCompat.Action.Builder(
                android.R.drawable.ic_media_next,
                "Berikutnya",
                pendingAction(ACTION_NEXT)).build());
        b.addAction(new NotificationCompat.Action.Builder(
                android.R.drawable.ic_media_ff,
                "+10",
                pendingAction(ACTION_FWD10)).build());
        b.addAction(new NotificationCompat.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Tutup",
                pendingAction(ACTION_STOP)).build());
        return b.build();
    }

    private PendingIntent pendingAction(String action) {
        Intent i = new Intent(this, MediaService.class).setAction(action);
        int requestCode = action.hashCode();
        return PendingIntent.getService(this, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void updatePlaybackState() {
        if (mediaSession == null) return;
        long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE
                | PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                | PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SEEK_TO;
        int state = playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
        mediaSession.setPlaybackState(new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, positionMs, 1.0f)
                .build());
    }

    private Bitmap decodeArt(String data) {
        if (TextUtils.isEmpty(data) || !data.startsWith("data:")) return null;
        int comma = data.indexOf(',');
        if (comma < 0) return null;
        try {
            byte[] bytes = android.util.Base64.decode(data.substring(comma + 1), android.util.Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private void clearAndStop() {
        try {
            if (mediaSession != null) mediaSession.setActive(false);
        } catch (Throwable ignored) {}
        try { stopForeground(true); } catch (Throwable ignored) {}
        foregroundStarted = false;
        running = false;
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    getString(com.kawaii.music.R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription(getString(com.kawaii.music.R.string.notification_channel_description));
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    private static String safe(String s) { return s == null ? "" : s; }

    @Override public void onDestroy() {
        running = false;
        try { if (mediaSession != null) mediaSession.release(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Nullable
    @Override public IBinder onBind(Intent intent) { return null; }
}
