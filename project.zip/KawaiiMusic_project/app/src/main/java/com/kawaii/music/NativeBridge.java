package com.kawaii.music;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.core.content.ContextCompat;

public class NativeBridge {
    private final MainActivity activity;
    private final Context context;
    private final WebView webView;

    NativeBridge(MainActivity activity, WebView webView) {
        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.webView = webView;
    }

    @JavascriptInterface
    public boolean hasAudioPermission() {
        return activity.hasAudioPermission();
    }

    @JavascriptInterface
    public void requestAudioPermission() {
        activity.runOnUiThread(activity::requestAudioPermissionIfNeeded);
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            activity.runOnUiThread(activity::requestNotificationPermissionIfNeeded);
        }
    }

    @JavascriptInterface
    public String scanAudio() {
        if (!activity.hasAudioPermission()) return "[]";
        return MediaLibrary.scan(context);
    }

    @JavascriptInterface
    public String mediaUrl(long syntheticOrMediaId) {
        long mediaId = Math.abs(syntheticOrMediaId);
        return "https://appassets.androidplatform.net/media/" + mediaId;
    }

    @JavascriptInterface
    public String albumArtUrl(long syntheticOrMediaId) {
        long mediaId = Math.abs(syntheticOrMediaId);
        return "https://appassets.androidplatform.net/art/" + mediaId;
    }

    @JavascriptInterface
    public void setTrackOverride(long syntheticOrMediaId, String title, String artist,
                                 String album, String artDataUrl) {
        long mediaId = Math.abs(syntheticOrMediaId);
        MediaLibrary.setOverride(context, mediaId, title, artist, album, artDataUrl);
    }

    @JavascriptInterface
    public void update(String title, String artist, String album, String artDataUrl,
                       boolean playing, long positionMs, long durationMs) {
        MediaService.update(context, title, artist, album, artDataUrl, playing, positionMs, durationMs);
    }

    @JavascriptInterface
    public void clear() {
        context.stopService(new Intent(context, MediaService.class));
    }
}
