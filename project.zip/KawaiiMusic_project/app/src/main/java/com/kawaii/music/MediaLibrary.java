package com.kawaii.music;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

final class MediaLibrary {
    private static final String PREF = "track_overrides";
    private static final String ART_PREFIX = "album_art_";

    private MediaLibrary() {}

    static String scan(Context context) {
        JSONArray out = new JSONArray();
        ContentResolver cr = context.getContentResolver();
        Uri collection = getCollection();
        String[] projection = new String[]{
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_ADDED
        };

        String sort = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";
        try (Cursor c = cr.query(collection, projection, null, null, sort)) {
            if (c == null) return out.toString();
            int idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int nameCol = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME);
            int titleCol = c.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int artistCol = c.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int albumCol = c.getColumnIndex(MediaStore.Audio.Media.ALBUM);
            int mimeCol = c.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE);
            int durCol = c.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int sizeCol = c.getColumnIndex(MediaStore.Audio.Media.SIZE);
            int dateCol = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED);

            while (c.moveToNext()) {
                long id = c.getLong(idCol);
                String display = get(c, nameCol);
                String title = clean(get(c, titleCol));
                String artist = clean(get(c, artistCol));
                String album = clean(get(c, albumCol));
                if (TextUtils.isEmpty(title)) title = stripExtension(display);
                if (TextUtils.isEmpty(artist)) artist = "Unknown";
                if (TextUtils.isEmpty(album)) album = "Unknown album";

                JSONObject o = new JSONObject();
                try {
                    o.put("id", -Math.abs(id));
                    o.put("mediaId", id);
                    o.put("t", title);
                    o.put("a", artist);
                    o.put("al", album);
                    o.put("u", "https://appassets.androidplatform.net/media/" + id);
                    o.put("cover", "https://appassets.androidplatform.net/art/" + id);
                    o.put("n", 1);
                    o.put("mime", clean(get(c, mimeCol)));
                    o.put("dur", durCol >= 0 ? c.getLong(durCol) : 0);
                    o.put("size", sizeCol >= 0 ? c.getLong(sizeCol) : 0);
                    o.put("added", dateCol >= 0 ? c.getLong(dateCol) : 0);
                    o.put("artCustom", hasCustomArt(context, id));
                    applyOverride(context, id, o);
                    out.put(o);
                } catch (Exception ignored) {
                }
            }
        } catch (SecurityException ignored) {
            return "[]";
        }
        return out.toString();
    }

    private static Uri getCollection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        }
        return MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    }

    static Uri mediaUri(long id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return ContentUris.withAppendedId(
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), id);
        }
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
    }

    static byte[] readEmbeddedArt(Context context, long id) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(context, mediaUri(id));
            byte[] art = mmr.getEmbeddedPicture();
            return art == null ? null : compressForNotification(art);
        } catch (Throwable ignored) {
            return null;
        } finally {
            try { mmr.release(); } catch (Throwable ignored) {}
        }
    }

    static byte[] readCustomArt(Context context, long id) {
        File f = artFile(context, id);
        if (!f.isFile()) return null;
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            ByteArrayOutputStream out = new ByteArrayOutputStream((int)Math.min(f.length(), 512 * 1024));
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            in.close();
            return out.toByteArray();
        } catch (Throwable ignored) {
            return null;
        }
    }

    static void setOverride(Context context, long id, String title, String artist,
                            String album, String artDataUrl) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        p.edit()
                .putString(id + ".t", title == null ? "" : title)
                .putString(id + ".a", artist == null ? "" : artist)
                .putString(id + ".al", album == null ? "" : album)
                .apply();

        File f = artFile(context, id);
        if (artDataUrl != null && artDataUrl.startsWith("data:")) {
            try {
                int comma = artDataUrl.indexOf(',');
                byte[] bytes = Base64.decode(artDataUrl.substring(comma + 1), Base64.DEFAULT);
                FileOutputStream out = new FileOutputStream(f);
                out.write(bytes);
                out.flush();
                out.close();
                return;
            } catch (Throwable ignored) {
            }
        }
        if (f.exists()) {
            // An empty art string means remove the per-track custom cover.
            // Keep the original MediaStore embedded artwork as fallback.
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }

    private static void applyOverride(Context context, long id, JSONObject o) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String t = p.getString(id + ".t", "");
        String a = p.getString(id + ".a", "");
        String al = p.getString(id + ".al", "");
        try {
            if (!TextUtils.isEmpty(t)) o.put("t", t);
            if (!TextUtils.isEmpty(a)) o.put("a", a);
            if (!TextUtils.isEmpty(al)) o.put("al", al);
            if (hasCustomArt(context, id)) o.put("cover", "https://appassets.androidplatform.net/art/" + id);
        } catch (Exception ignored) {}
    }

    static boolean hasCustomArt(Context context, long id) {
        return artFile(context, id).isFile();
    }

    static byte[] readArt(Context context, long id) {
        byte[] custom = readCustomArt(context, id);
        return custom != null ? custom : readEmbeddedArt(context, id);
    }

    private static File artFile(Context context, long id) {
        return new File(context.getFilesDir(), ART_PREFIX + id + ".jpg");
    }

    private static String get(Cursor c, int col) {
        return col >= 0 && !c.isNull(col) ? c.getString(col) : "";
    }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.equalsIgnoreCase("<unknown>")) return "";
        return s;
    }

    private static String stripExtension(String s) {
        if (s == null) return "";
        int dot = s.lastIndexOf('.');
        return dot > 0 ? s.substring(0, dot) : s;
    }

    private static byte[] compressForNotification(byte[] raw) {
        android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length);
        if (bm == null) return raw;
        int side = Math.min(bm.getWidth(), bm.getHeight());
        int left = Math.max(0, (bm.getWidth() - side) / 2);
        int top = Math.max(0, (bm.getHeight() - side) / 2);
        Bitmap crop = Bitmap.createBitmap(bm, left, top, side, side);
        Bitmap scaled = Bitmap.createScaledBitmap(crop, 256, 256, true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, out);
        if (scaled != crop) scaled.recycle();
        if (crop != bm) crop.recycle();
        bm.recycle();
        return out.toByteArray();
    }
}
