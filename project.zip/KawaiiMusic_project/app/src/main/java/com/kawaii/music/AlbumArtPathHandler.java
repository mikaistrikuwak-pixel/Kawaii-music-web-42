package com.kawaii.music;

import android.content.Context;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

final class AlbumArtPathHandler implements WebViewAssetLoader.PathHandler {
    private final Context context;
    private static final byte[] FALLBACK = ("<svg xmlns='http://www.w3.org/2000/svg' width='256' height='256' viewBox='0 0 256 256'>"
            + "<defs><linearGradient id='g' x2='1' y2='1'><stop stop-color='#c5b7f7'/><stop offset='1' stop-color='#ffd7e5'/></linearGradient></defs>"
            + "<rect width='256' height='256' rx='46' fill='url(#g)'/><circle cx='128' cy='128' r='52' fill='#fff' opacity='.6'/></svg>").getBytes(java.nio.charset.StandardCharsets.UTF_8);

    AlbumArtPathHandler(Context context) { this.context = context.getApplicationContext(); }

    @Override
    public WebResourceResponse handle(String path) {
        String s = path == null ? "" : path;
        while (s.startsWith("/")) s = s.substring(1);
        long id;
        try { id = Long.parseLong(s); } catch (Exception e) { return null; }
        if (id <= 0) return null;
        byte[] art = MediaLibrary.readArt(context, id);
        if (art == null || art.length == 0) {
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            return new WebResourceResponse("image/svg+xml", "UTF-8", 200, "OK", headers,
                    new ByteArrayInputStream(FALLBACK));
        }
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse("image/jpeg", null, 200, "OK", headers,
                new ByteArrayInputStream(art));
    }
}
