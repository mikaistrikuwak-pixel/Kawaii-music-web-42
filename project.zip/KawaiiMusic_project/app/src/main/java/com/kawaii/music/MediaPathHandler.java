package com.kawaii.music;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;

import java.io.BufferedInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

final class MediaPathHandler implements WebViewAssetLoader.PathHandler {
    private final Context context;

    MediaPathHandler(Context context) { this.context = context.getApplicationContext(); }

    @Override
    public WebResourceResponse handle(String path) {
        return handleRequest(context, path, null);
    }

    static WebResourceResponse handleRequest(Context context, String path, String rangeHeader) {
        String s = path == null ? "" : path;
        while (s.startsWith("/")) s = s.substring(1);
        if (s.startsWith("media/")) s = s.substring("media/".length());
        long id;
        try { id = Long.parseLong(s); } catch (Exception e) { return null; }
        if (id <= 0) return null;

        Uri uri = MediaLibrary.mediaUri(id);
        String mime = context.getContentResolver().getType(uri);
        if (mime == null) mime = "application/octet-stream";

        try {
            ParcelFileDescriptor pfd = context.getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return null;
            long length = pfd.getStatSize();
            long start = 0L;
            long end = length > 0 ? length - 1 : -1L;
            int status = 200;
            String reason = "OK";

            if (rangeHeader != null && rangeHeader.startsWith("bytes=") && length > 0) {
                String r = rangeHeader.substring(6).split(",", 2)[0].trim();
                int dash = r.indexOf('-');
                if (dash >= 0) {
                    String a = r.substring(0, dash).trim();
                    String b = r.substring(dash + 1).trim();
                    try {
                        if (a.isEmpty()) {
                            long suffix = Long.parseLong(b);
                            start = Math.max(0L, length - suffix);
                        } else {
                            start = Long.parseLong(a);
                        }
                        if (!b.isEmpty()) end = Math.min(length - 1, Long.parseLong(b));
                        else end = length - 1;
                        if (start >= length || start > end) {
                            pfd.close();
                            Map<String,String> h = new HashMap<>();
                            h.put("Content-Range", "bytes */" + length);
                            return new WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h, null);
                        }
                        status = 206;
                        reason = "Partial Content";
                    } catch (NumberFormatException ignored) {
                    }
                }
            }

            InputStream base = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            if (start > 0) {
                long left = start;
                while (left > 0) {
                    long skipped = base.skip(left);
                    if (skipped <= 0) { if (base.read() < 0) break; else skipped = 1; }
                    left -= skipped;
                }
            }
            long contentLength = end >= start ? (end - start + 1) : length;
            InputStream body = new BufferedInputStream(end >= start ? new LimitedInputStream(base, contentLength) : base, 32 * 1024);
            Map<String,String> headers = new HashMap<>();
            headers.put("Accept-Ranges", "bytes");
            headers.put("Content-Length", String.valueOf(contentLength));
            if (status == 206) headers.put("Content-Range", "bytes " + start + "-" + end + "/" + length);
            return new WebResourceResponse(mime, null, status, reason, headers, body);
        } catch (SecurityException | IOException ignored) {
            return null;
        }
    }

    private static final class LimitedInputStream extends FilterInputStream {
        private long remaining;
        LimitedInputStream(InputStream in, long limit) { super(in); remaining = Math.max(0, limit); }
        @Override public int read() throws IOException {
            if (remaining <= 0) return -1;
            int v = super.read();
            if (v >= 0) remaining--;
            return v;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (remaining <= 0) return -1;
            int n = super.read(b, off, (int)Math.min(len, remaining));
            if (n > 0) remaining -= n;
            return n;
        }
        @Override public long skip(long n) throws IOException {
            long k = super.skip(Math.min(n, remaining));
            if (k > 0) remaining -= k;
            return k;
        }
    }
}
